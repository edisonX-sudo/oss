package org.perfma.domain.shared;

public class EventTriggerImpl extends EventBus.EventTrigger {
    @Override
    public void trigger(DomainEvent popEvent) {
        // TODO use spring event / event bus
    }
}
