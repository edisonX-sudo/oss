package org.perfma.domain.employee;

import org.perfma.mapper.EmployeeMapper;
import org.perfma.po.EmployeePo;

//该模块与domain模块包名相同,用以得到访问其包级别字段的权限
public class EmployeeRepoImpl implements EmployeeRepo {
    EmployeeMapper employeeMapper;

    @Override
    public boolean exist(String username) {
        // TODO: 2022/5/11
        return false;
    }

    @Override
    public Employee find(String username) {
        // TODO: 2022/5/11
        return null;
    }

    @Override
    public Employee find(EmployeeId id) {
        // TODO: 2022/5/11
        return null;
    }

    @Override
    public EmployeeId save(Employee employee) {
        if (employee.id == null) {
            EmployeePo employeePo = assembleEmployeePo(employee);
            employeeMapper.insert(employeePo);
            return new EmployeeId(employeePo.getId());
        } else {
            employeeMapper.update(assembleEmployeePo(employee));
            return employee.id;
        }
    }

    private EmployeePo assembleEmployeePo(Employee employee) {
        return new EmployeePo();
    }

}
