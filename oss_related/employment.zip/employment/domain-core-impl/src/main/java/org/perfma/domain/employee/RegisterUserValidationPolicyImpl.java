package org.perfma.domain.employee;

public class RegisterUserValidationPolicyImpl extends SendNewUserValidationEmailPolicy {
    final String activationLinkTemplate = "http://localhost:8080/activate/%s";

    @Override
    void renderAndSendActivationEmail(String email, String username, String validationTemplate) {
        String activationLink = String.format(activationLinkTemplate, username);
        String emailContent = String.format(validationTemplate, username, activationLink);
        sendEmail(email, emailContent);
    }

    private void sendEmail(String email, String emailContent) {
        // TODO: 2022/5/11
    }
}
