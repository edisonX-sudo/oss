package org.perfma.application;

import lombok.AllArgsConstructor;
import org.perfma.domain.shared.DomainAbility;
import org.perfma.domain.shared.DomainEvent;
import org.perfma.domain.shared.EventBus;

import java.util.Arrays;

@DomainAbility
@AllArgsConstructor
public class EventBusService {
    EventBus.EventTrigger eventTrigger;

    public void occur(DomainEvent... domainEvents) {
        Arrays.stream(domainEvents).forEach((e) -> eventTrigger.trigger(e));
    }
}
