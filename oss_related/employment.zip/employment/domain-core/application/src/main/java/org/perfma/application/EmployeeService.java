package org.perfma.application;

import lombok.AllArgsConstructor;
import org.perfma.domain.employee.*;
import org.perfma.domain.shared.DomainAbility;

import java.util.List;

@DomainAbility
@AllArgsConstructor
public class EmployeeService {
    EmployeeFactory employeeFactory;
    EmployeeRepo employeeRepo;
    FriendingService friendingService;

    public EmployeeId register(RealName realName, String userName, String password,
                               String email, List<WorkExperience> workExperiences) {
        Employee employee = employeeFactory.create(realName, userName, password, email, workExperiences);
        return employeeRepo.save(employee);
    }

    public void uploadResume(EmployeeId employeeId, String resumeUrl) {
        Employee employee = employeeRepo.find(employeeId);
        EmployeeRepo.checkNull(employee);
        employee.uploadResume(resumeUrl);
        employeeRepo.save(employee);
    }

    public void friending(EmployeeId toFriendEmployeeId, EmployeeId beFriendedEmployeeId) {
        Employee toFriendEmployee = employeeRepo.find(toFriendEmployeeId);
        Employee beFriendedEmployee = employeeRepo.find(beFriendedEmployeeId);

        friendingService.friending(toFriendEmployee, beFriendedEmployee);
        /*
         *   相对上面一行代码的另一从方式的调用, 代码多一行null-check,但friending关联性更强(直接与Employee关联)
         *   EmployeeRepo.checkNull(toFriendEmployee);
         *   toFriendEmployee.friending(beFriendedEmployee, friendingService);
         * */
    }
}
