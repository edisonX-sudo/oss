package org.perfma.domain.shared;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;

@Retention(java.lang.annotation.RetentionPolicy.RUNTIME)
@Documented
public @interface DomainAbility {
}
