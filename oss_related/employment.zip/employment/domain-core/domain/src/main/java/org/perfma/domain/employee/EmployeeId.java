package org.perfma.domain.employee;

import lombok.EqualsAndHashCode;
import org.perfma.domain.shared.Id;

@EqualsAndHashCode
public class EmployeeId implements Id<Long> {
    private Long code;

    public EmployeeId(Long code) {
        this.code = code;
    }

    @Override
    public Long code() {
        return code;
    }
}
