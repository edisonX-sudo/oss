package org.perfma.domain.shared;

public abstract class DomainPolicy<T extends DomainEvent> {
    public abstract void subscribe(T event);
}
