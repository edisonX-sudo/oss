package org.perfma.domain.employee;

import org.perfma.domain.shared.DomainPolicy;

public abstract class SendNewUserValidationEmailPolicy extends DomainPolicy<EmployeeCreated> {
    final String validationTemplate = "Hi, %s!\npls click link below to activate your account:\n %s";

    @Override
    public void subscribe(EmployeeCreated employeeCreated) {
        String email = employeeCreated.email;
        String username = employeeCreated.username;
        renderAndSendActivationEmail(email, username, validationTemplate);
    }

    abstract void renderAndSendActivationEmail(String email, String username, String validationTemplate);
}
