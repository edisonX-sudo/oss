package org.perfma.domain.shared;


public interface Entity extends AggregateComponent {

}
