package org.perfma.domain.shared;

import java.util.ArrayDeque;
import java.util.Queue;
import java.util.function.Consumer;

public class EventBus {
    private static ThreadLocal<Queue<DomainEvent>> domainEventList = ThreadLocal.withInitial(ArrayDeque::new);

    public static void foreach(Consumer<DomainEvent> consumer) {
        getCurrentEventList().forEach(consumer);
    }

    public static void occur(DomainEvent domainEvent) {
        getCurrentEventList().add(domainEvent);
    }

    public static void clean() {
        domainEventList.set(new ArrayDeque<>());
    }

    private static Queue<DomainEvent> getCurrentEventList() {
        return domainEventList.get();
    }

    public abstract static class EventTrigger {

        public void triggerEventInQueue() {
            EventBus.foreach(this::trigger);
            EventBus.clean();
        }

        public abstract void trigger(DomainEvent popEvent);
    }

}
