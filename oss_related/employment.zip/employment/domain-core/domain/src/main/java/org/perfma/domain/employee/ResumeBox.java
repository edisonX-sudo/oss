package org.perfma.domain.employee;

import lombok.EqualsAndHashCode;
import lombok.NonNull;
import org.perfma.domain.shared.ValueObject;
import org.perfma.domain.utils.DomainCollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@EqualsAndHashCode
public class ResumeBox implements ValueObject {
    final List<String> resumeUrlList;

    public ResumeBox(@NonNull List<String> resumeUrlList) {
        if (resumeUrlList.size() > 3)
            throw new ResumeCountOverLimit();
        this.resumeUrlList = resumeUrlList;
    }

    public List<String> resumeUrlList() {
        return DomainCollectionUtils.sealedList(resumeUrlList);
    }
}
