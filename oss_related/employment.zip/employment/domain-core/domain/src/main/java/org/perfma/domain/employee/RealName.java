package org.perfma.domain.employee;

import lombok.EqualsAndHashCode;
import lombok.NonNull;
import org.perfma.domain.shared.ValueObject;

@EqualsAndHashCode
public class RealName implements ValueObject {
    final String firstName;
    final String lastName;

    public RealName(@NonNull String firstName, @NonNull String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
}
