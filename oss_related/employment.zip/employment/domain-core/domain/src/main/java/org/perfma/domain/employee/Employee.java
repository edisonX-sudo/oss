package org.perfma.domain.employee;


import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.val;
import org.perfma.domain.shared.Entity;
import org.perfma.domain.utils.DomainCollectionUtils;

import java.util.List;

@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Employee implements Entity {
    @EqualsAndHashCode.Include
    EmployeeId id;
    RealName realName;
    String username;
    String password;
    String email;
    List<WorkExperience> workExperiences;
    ResumeBox resumeBox;
    FriendList friendList;

    Employee(@NonNull RealName realName, @NonNull String username,
             @NonNull String password, @NonNull String email, @NonNull List<WorkExperience> workExperiences) {
        this.realName = realName;
        this.username = username;
        this.password = password;
        this.email = email;
        this.workExperiences = workExperiences;
    }

    public void uploadResume(String resumeUrl) {
        List<String> resumeUrlList = resumeBox.resumeUrlList();
        resumeBox = new ResumeBox(retNewListWithElements(resumeUrlList, resumeUrl));
    }
}
