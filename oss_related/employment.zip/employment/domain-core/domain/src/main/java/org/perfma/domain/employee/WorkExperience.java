package org.perfma.domain.employee;

import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.experimental.NonFinal;
import org.perfma.domain.shared.ValueObject;

import java.time.LocalDateTime;

@EqualsAndHashCode
public class WorkExperience implements ValueObject {
    final String companyName;
    final LocalDateTime startTime;
    final LocalDateTime endTime;


    public WorkExperience(@NonNull String companyName, @NonNull LocalDateTime startTime, @NonNull LocalDateTime endTime) {
        if (startTime.isAfter(endTime))
            throw new StartTimeAfterEndTime();
        if (endTime.isAfter(LocalDateTime.now()))
            throw new EndTimeAfterNow();
        this.startTime = startTime;
        this.endTime = endTime;
        this.companyName = companyName;
    }
}
