package org.perfma.domain.shared;

import org.perfma.domain.utils.DomainCollectionUtils;
import org.perfma.domain.utils.Finder;

import java.util.List;
import java.util.Map;

public interface AggregateComponent {

    default <T> List<T> retNewListWithElements(List<T> srcList, T... elements) {
        return DomainCollectionUtils.retNewListWithElements(srcList, elements);
    }

    default <K, V> Map<K, V> retNewMapWithElementMap(Map<K, V> srcMap, Map<K, V> elementMap) {
        return DomainCollectionUtils.retNewMapWithElementMap(srcMap, elementMap);
    }

    default <T> List<T> sealedList(List<T> list) {
        return DomainCollectionUtils.sealedList(list);
    }

    default <K, V> Map<K, V> sealedMap(Map<K, V> map) {
        return DomainCollectionUtils.sealedMap(map);
    }
}
