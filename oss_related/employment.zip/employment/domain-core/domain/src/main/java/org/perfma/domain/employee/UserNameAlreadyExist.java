package org.perfma.domain.employee;

import org.perfma.domain.shared.DomainException;

public class UserNameAlreadyExist extends DomainException {
    public UserNameAlreadyExist() {
        super("username already exists");
    }
}
