package org.perfma.domain.shared;

public abstract class DomainException extends RuntimeException implements ValueObject {
    public DomainException(String message) {
        super(message);
    }
}
