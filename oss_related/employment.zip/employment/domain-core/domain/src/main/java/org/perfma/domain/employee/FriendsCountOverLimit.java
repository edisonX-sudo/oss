package org.perfma.domain.employee;

import org.perfma.domain.shared.DomainException;

public class FriendsCountOverLimit extends DomainException {
    public FriendsCountOverLimit() {
        super("FriendList can only contain 500 friends");
    }
}
