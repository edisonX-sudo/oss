package org.perfma.domain.employee;

import org.perfma.domain.shared.DomainException;

public class ResumeCountOverLimit extends DomainException {
    public ResumeCountOverLimit() {
        super("ResumeBox can only contain 3 resumes");
    }
}
