package org.perfma.domain.shared;


public interface Id<T> extends ValueObject {
    T code();
}
