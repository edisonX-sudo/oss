package org.perfma.domain.utils;

import java.util.*;

public class DomainCollectionUtils {
    public static <T> List<T> retNewListWithElements(List<T> srcList, T... element) {
        if (srcList == null) srcList = new ArrayList<>();
        ArrayList<T> ts = new ArrayList<>(srcList);
        if (element == null) return ts;
        ts.addAll(Arrays.asList(element));
        return ts;
    }

    public static <K, V> Map<K, V> retNewMapWithElementMap(Map<K, V> srcMap, Map<K, V> elementMap) {
        if (srcMap == null) srcMap = new HashMap<>();
        Map<K, V> map = new HashMap<>(srcMap);
        if (elementMap == null) return map;
        map.putAll(elementMap);
        return map;
    }

    public static <T> List<T> sealedList(List<T> srcList) {
        if (srcList == null) return Collections.emptyList();
        return Collections.unmodifiableList(srcList);
    }

    public static <K, V> Map<K, V> sealedMap(Map<K, V> map) {
        if (map == null) return Collections.emptyMap();
        return Collections.unmodifiableMap(map);
    }
}
