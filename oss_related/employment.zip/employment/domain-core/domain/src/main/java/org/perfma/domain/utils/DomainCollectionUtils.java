package org.perfma.domain.utils;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class DomainCollectionUtils {
    public static <T> List<T> append2CopiedList(List<T> srcList, T... element) {
        ArrayList<T> ts = new ArrayList<>(srcList);
        ts.addAll(Arrays.asList(element));
        return ts;
    }

    public static <T> List<T> sealedList(List<T> srcList) {
        return Collections.unmodifiableList(srcList);
    }
}
