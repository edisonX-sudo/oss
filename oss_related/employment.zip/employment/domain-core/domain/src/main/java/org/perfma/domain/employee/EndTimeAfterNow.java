package org.perfma.domain.employee;

import org.perfma.domain.shared.DomainException;

public class EndTimeAfterNow extends DomainException {
    public EndTimeAfterNow() {
        super("endTime can not be after now");
    }
}
