package org.perfma.domain.utils;

public abstract class Finder {
    private static Finder instance = null;

    public static void setInstance(Finder instance) {
        if (Finder.instance != null) {
            throw new IllegalStateException("instance already set");
        }
        Finder.instance = instance;
    }

    public static Finder instance() {
        return instance;
    }

    public abstract <T> T lookup(Class<T> clazz);
}
