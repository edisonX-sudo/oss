package org.perfma.domain.employee;

import lombok.EqualsAndHashCode;
import lombok.NonNull;
import org.perfma.domain.shared.DomainEvent;

import java.time.LocalDateTime;

@EqualsAndHashCode
public class EmployeeCreated implements DomainEvent {
    final String username;
    final String email;
    private LocalDateTime occurredOn;

    public EmployeeCreated(@NonNull String username, @NonNull String email) {
        this.username = username;
        this.email = email;
        this.occurredOn = LocalDateTime.now();
    }

    @Override
    public LocalDateTime occurredOn() {
        return occurredOn;
    }
}
