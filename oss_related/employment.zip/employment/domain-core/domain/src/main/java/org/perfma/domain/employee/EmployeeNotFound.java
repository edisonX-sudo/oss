package org.perfma.domain.employee;

import org.perfma.domain.shared.DomainException;

public class EmployeeNotFound extends DomainException {
    public EmployeeNotFound() {
        super("employee not found");
    }
}
