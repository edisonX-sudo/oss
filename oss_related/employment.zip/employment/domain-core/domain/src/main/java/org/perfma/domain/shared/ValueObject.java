package org.perfma.domain.shared;

public interface ValueObject {
}
