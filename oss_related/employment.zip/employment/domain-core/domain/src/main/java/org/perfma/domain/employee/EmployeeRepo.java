package org.perfma.domain.employee;

public interface EmployeeRepo {
    boolean exist(String username);

    Employee find(String username);

    Employee find(EmployeeId id);

    EmployeeId save(Employee employee);

    static void checkNull(Employee employee){
        if(employee == null){
            throw new EmployeeNotFound();
        }
    }
}
