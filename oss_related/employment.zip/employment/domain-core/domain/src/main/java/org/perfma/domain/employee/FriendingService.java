package org.perfma.domain.employee;

import lombok.AllArgsConstructor;
import org.perfma.domain.shared.DomainAbility;
import org.perfma.domain.utils.DomainCollectionUtils;

import java.util.List;

@DomainAbility
@AllArgsConstructor
public class FriendingService {

    public void friending(Employee toFriendEmployee, Employee beFriendedEmployee) {
        EmployeeRepo.checkNull(toFriendEmployee);
        EmployeeRepo.checkNull(beFriendedEmployee);
        EmployeeId beFriendedId = beFriendedEmployee.id;
        List<EmployeeId> friendList = toFriendEmployee.friendList.friendList();
        toFriendEmployee.friendList = new FriendList(DomainCollectionUtils.retNewListWithElements(friendList, beFriendedId));
    }
}
