package org.perfma.domain.employee;

import lombok.EqualsAndHashCode;
import lombok.NonNull;
import org.perfma.domain.shared.ValueObject;
import org.perfma.domain.utils.DomainCollectionUtils;

import java.util.List;

@EqualsAndHashCode
public class FriendList implements ValueObject {
    final List<EmployeeId> friendNameList;

    public FriendList(@NonNull List<EmployeeId> friendNameList) {
        if (friendNameList.size() > 500)
            throw new FriendsCountOverLimit();
        this.friendNameList = friendNameList;
    }

    public List<EmployeeId> friendList() {
        return DomainCollectionUtils.sealedList(friendNameList);
    }
}
