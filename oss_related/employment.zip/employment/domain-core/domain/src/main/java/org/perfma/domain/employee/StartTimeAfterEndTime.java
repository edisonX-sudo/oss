package org.perfma.domain.employee;

import org.perfma.domain.shared.DomainException;

public class StartTimeAfterEndTime extends DomainException {
    public StartTimeAfterEndTime() {
        super("StartTime can not be after end time");
    }
}
