package org.perfma.domain.employee;

import lombok.AllArgsConstructor;
import org.perfma.domain.shared.DomainAbility;
import org.perfma.domain.shared.EventBus;

import java.util.List;

@DomainAbility
@AllArgsConstructor
public class EmployeeFactory {
    EmployeeRepo employeeRepo;

    public Employee create(RealName realName, String username, String password,
                           String email, List<WorkExperience> workExperiences) {
        if (employeeRepo.exist(username))
            throw new UserNameAlreadyExist();
        Employee employee = new Employee(realName, username, password, email, workExperiences);
        EventBus.occur(new EmployeeCreated(username, email));
        return employee;
    }
}
