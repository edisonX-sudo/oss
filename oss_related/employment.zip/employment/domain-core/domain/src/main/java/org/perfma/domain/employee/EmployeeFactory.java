package org.perfma.domain.employee;

import org.perfma.domain.shared.EventBus;

import java.util.List;

public class EmployeeFactory {
    EmployeeRepo employeeRepo;

    public Employee create(RealName realName, String username, String password,
                           String email, List<WorkExperience> workExperiences) {
        if (employeeRepo.exist(username))
            throw new UserNameAlreadyExist();
        Employee employee = new Employee(realName, username, password, email, workExperiences);
        EventBus.occur(new EmployeeCreated(username, email));
        return employee;
    }
}
