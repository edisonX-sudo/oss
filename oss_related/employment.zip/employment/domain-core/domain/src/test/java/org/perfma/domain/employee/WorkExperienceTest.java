package org.perfma.domain.employee;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class WorkExperienceTest {

    @Test
    void testGenerate() {
        LocalDateTime startTime = LocalDateTime.now().minusDays(1);
        LocalDateTime endTime = LocalDateTime.now();
        WorkExperience experience = new WorkExperience("companyName", startTime, endTime);
        assertEquals("companyName", experience.companyName);
        assertEquals(startTime, experience.startTime);
        assertEquals(endTime, experience.endTime);
    }

    @Test
    void testStartTimeAfterEndTime() {
        StartTimeAfterEndTime startTimeAfterEndTime = assertThrows(StartTimeAfterEndTime.class, () -> {
            LocalDateTime startTime = LocalDateTime.now().plusDays(1);
            LocalDateTime endTime = LocalDateTime.now();
            new WorkExperience("companyName", startTime, endTime);
        });
        assertNotNull(startTimeAfterEndTime);
    }

    @Test
    void testEndTimeAfterNow() {
        EndTimeAfterNow endTimeAfterNow = assertThrows(EndTimeAfterNow.class, () -> {
            LocalDateTime startTime = LocalDateTime.now().minusDays(1);
            LocalDateTime endTime = LocalDateTime.now().plusDays(1);
            new WorkExperience("companyName", startTime, endTime);
        });
        assertNotNull(endTimeAfterNow);
    }

    @Test
    void testNullCompanyName() {
        NullPointerException nullPointerException = assertThrows(NullPointerException.class, () -> {
            LocalDateTime startTime = LocalDateTime.now().minusDays(1);
            LocalDateTime endTime = LocalDateTime.now();
            new WorkExperience(null, startTime, endTime);
        });
        assertTrue(nullPointerException.getMessage().contains("companyName"));
    }

    @Test
    void testNullStartTimeName() {
        NullPointerException nullPointerException = assertThrows(NullPointerException.class, () -> {
            LocalDateTime startTime = null;
            LocalDateTime endTime = LocalDateTime.now();
            new WorkExperience("companyName", startTime, endTime);
        });
        assertTrue(nullPointerException.getMessage().contains("startTime"));
    }

    @Test
    void testNullEndTimeName() {
        NullPointerException nullPointerException = assertThrows(NullPointerException.class, () -> {
            LocalDateTime startTime = LocalDateTime.now().minusDays(1);
            LocalDateTime endTime = null;
            new WorkExperience("companyName", startTime, endTime);
        });
        assertTrue(nullPointerException.getMessage().contains("endTime"));
    }


}