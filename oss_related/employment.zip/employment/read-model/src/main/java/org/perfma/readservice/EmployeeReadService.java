package org.perfma.readservice;

import org.perfma.mapper.EmployeeMapper;

public class EmployeeReadService {
    EmployeeMapper employeeMapper;

    public org.perfma.facade.employee.read.resp.FetchInfoResp fetchInfo(Object userName) {
        return null;
    }
}
