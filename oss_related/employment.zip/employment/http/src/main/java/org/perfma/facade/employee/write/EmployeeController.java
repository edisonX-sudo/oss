package org.perfma.facade.employee.write;

import org.perfma.Result;
import org.perfma.domain.employee.EmployeeId;
import org.perfma.domain.employee.RealName;
import org.perfma.domain.employee.WorkExperience;
import org.perfma.facade.employee.write.req.RegisterReqDto;
import org.perfma.facade.employee.write.req.UploadResumeReqDto;
import org.perfma.facade.employee.write.req.WorkExperienceReqDto;
import org.perfma.facade.employee.write.resp.RegisterRespDto;
import org.perfma.service.EmployeeService;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class EmployeeController {
    EmployeeService employeeService;

    public Result<RegisterRespDto> register(RegisterReqDto req) {
        RealName realName = new RealName(req.getFirstName(), req.getLastName());
        List<WorkExperience> workExperiences = assembleWorkExperiences(req);
        EmployeeId registerEmployee = employeeService
                .register(realName, req.getUserName(), req.getPassword(), req.getEmail(), workExperiences);
        return Result.ofSuccess(new RegisterRespDto(registerEmployee.code()));
    }

    private List<WorkExperience> assembleWorkExperiences(RegisterReqDto req) {
        return req.getWorkExperiences()
                .stream()
                .map(dto -> new WorkExperience(dto.getCompanyName(), dto.getStartTime(), dto.getEndTime()))
                .collect(Collectors.toList());
    }

    public Result<?> uploadResume(UploadResumeReqDto req) {
        employeeService.uploadResume(new EmployeeId(req.getEmployeeId()), req.getResumeUrl());
        return Result.ofSuccess();
    }
}
