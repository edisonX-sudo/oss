package org.perfma.facade.employee.write.req;

import lombok.Data;

import java.util.List;

@Data
public class RegisterReqDto {
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    private String email;
    private List<WorkExperienceReqDto> workExperiences;

}
