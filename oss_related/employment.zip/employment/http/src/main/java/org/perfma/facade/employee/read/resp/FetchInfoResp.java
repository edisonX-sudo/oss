package org.perfma.facade.employee.read.resp;

import lombok.Data;

@Data
public class FetchInfoResp {
}
