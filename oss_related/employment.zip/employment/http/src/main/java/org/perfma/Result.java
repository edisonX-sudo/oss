package org.perfma;

import lombok.Data;

@Data
public class Result<T> {
    String code;
    String msg;
    Boolean success;
    T data;

    public static <T> Result<T> ofSuccess() {
        Result<T> result = new Result<>();
        result.setCode("200");
        result.setMsg("success");
        result.setSuccess(true);
        result.setData(null);
        return result;
    }

    public static <T> Result<T> ofSuccess(T data) {
        Result<T> result = new Result<>();
        result.setCode("200");
        result.setMsg("success");
        result.setSuccess(true);
        result.setData(data);
        return result;
    }

    public static <T>Result<T> ofFailed(T data) {
        Result<T> result = new Result<>();
        result.setCode("500");
        result.setMsg("failed");
        result.setSuccess(false);
        result.setData(data);
        return result;
    }
}
