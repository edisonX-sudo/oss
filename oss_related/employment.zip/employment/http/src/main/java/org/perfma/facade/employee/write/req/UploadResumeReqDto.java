package org.perfma.facade.employee.write.req;

import lombok.Data;

@Data
public class UploadResumeReqDto {
    Long employeeId;
    String resumeUrl;
}
