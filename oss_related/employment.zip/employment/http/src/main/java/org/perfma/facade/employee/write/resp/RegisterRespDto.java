package org.perfma.facade.employee.write.resp;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RegisterRespDto {
    private Long id;
}
