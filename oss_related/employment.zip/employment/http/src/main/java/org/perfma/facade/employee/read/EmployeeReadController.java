package org.perfma.facade.employee.read;

import org.perfma.Result;
import org.perfma.facade.employee.read.req.FetchInfoReq;
import org.perfma.facade.employee.read.resp.FetchInfoResp;
import org.perfma.readservice.EmployeeReadService;

public class EmployeeReadController {
    EmployeeReadService employeeReadService;
    public Result<FetchInfoResp> fetchInfo(FetchInfoReq req) {
        FetchInfoResp resp = employeeReadService.fetchInfo(req.getUserName());
        return Result.ofSuccess(resp);
    }
}
