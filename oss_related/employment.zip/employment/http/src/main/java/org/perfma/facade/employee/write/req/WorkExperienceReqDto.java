package org.perfma.facade.employee.write.req;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class WorkExperienceReqDto {
    private String companyName;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
}
