package org.perfma.facade.employee.read.req;

import lombok.Data;

@Data
public class FetchInfoReq {
    private Object userName;
}
