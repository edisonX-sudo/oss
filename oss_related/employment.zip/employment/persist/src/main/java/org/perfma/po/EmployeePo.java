package org.perfma.po;

import lombok.Data;

@Data
public class EmployeePo {
    long id;
}
