package org.perfma.mapper;

import org.perfma.po.EmployeePo;

public interface EmployeeMapper {
    void insert(EmployeePo employeePo);

    void update(EmployeePo employeePo);
}
